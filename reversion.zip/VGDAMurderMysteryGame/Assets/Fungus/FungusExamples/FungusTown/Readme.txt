This demo shows how to setup parallax scrolling sprite effects.

The Fungus Town artwork in this scene was contibuted by super artist and all round gentleman Denman Rooke!

Check out more of Denman's stunning work here:
http://denmanrooke.com
http://www.twitch.tv/denmanrooke
https://twitter.com/denmanrooke

=============

White smoke particle system based on this tutorial by Xenosmash Games
https://www.youtube.com/watch?v=GebwdChivxI

=============
